﻿Imports System.Net
Imports System.Text.RegularExpressions
Imports System.Web.Services

' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
<System.Web.Script.Services.ScriptService()> _
<WebService(Namespace:="http://tempuri.org/")> _
<WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
Public Class WebService2
    Inherits System.Web.Services.WebService
    <WebMethod()> _
    Public Function CurrencyConversion(ByVal amount As Decimal, ByVal fromCurrency As String, ByVal toCurrency As String) As String
        Dim web As New WebClient()
        Dim url As String = String.Format("http://www.google.com/ig/calculator?hl=en&q={2}{0}%3D%3F{1}", fromCurrency.ToUpper(), toCurrency.ToUpper(), amount)
        Dim response As String = web.DownloadString(url)
        Dim regex As New Regex(":(?<rhs>.+?),")
        Dim arrDigits As String() = regex.Split(response)
        Dim rate As String = arrDigits(3)
        Return rate
    End Function
End Class
