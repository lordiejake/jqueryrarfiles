﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Configuration

Partial Class VB
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            BindGrid()
        End If
    End Sub
   
    Private Sub BindGrid()
        Dim strConnString As String = ConfigurationManager.ConnectionStrings("constr").ConnectionString
        Using con As New SqlConnection(strConnString)
            Using cmd As New SqlCommand()
                cmd.CommandText = "select Id, Name from tblFiles"
                cmd.Connection = con
                con.Open()
                GridView1.DataSource = cmd.ExecuteReader()
                GridView1.DataBind()
                con.Close()
            End Using
        End Using
    End Sub

    Protected Sub btnUpload_Click(sender As Object, e As EventArgs)
        Using br As New BinaryReader(FileUpload1.PostedFile.InputStream)
            Dim bytes As Byte() = br.ReadBytes(CInt(FileUpload1.PostedFile.InputStream.Length))
            Dim strConnString As String = ConfigurationManager.ConnectionStrings("constr").ConnectionString
            Using con As New SqlConnection(strConnString)
                Using cmd As New SqlCommand()
                    cmd.CommandText = "insert into tblFiles(Name, ContentType, Data) values (@Name, @ContentType, @Data)"
                    cmd.Parameters.AddWithValue("@Name", Path.GetFileName(FileUpload1.PostedFile.FileName))
                    cmd.Parameters.AddWithValue("@ContentType", "audio/mpeg3")
                    cmd.Parameters.AddWithValue("@Data", bytes)
                    cmd.Connection = con
                    con.Open()
                    cmd.ExecuteNonQuery()
                    con.Close()
                End Using
            End Using
        End Using
        Response.Redirect(Request.Url.AbsoluteUri)
    End Sub
End Class
