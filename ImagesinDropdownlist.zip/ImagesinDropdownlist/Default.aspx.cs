﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;


public partial class _Default : System.Web.UI.Page 
{
protected void Page_Load(object sender, EventArgs e)
{
    if (!IsPostBack)
    {
        BindDropDownList();
        BindTitles();
        lbltext.Text = ddlCountry.Items[0].Text;
    }
}
/// <summary>
/// This Method is used to bind titles to each element of dropdown
/// </summary>
protected void BindTitles()
{
    if (ddlCountry != null)
    {
        foreach (ListItem li in ddlCountry.Items)
        {
            li.Attributes["title"] = "Images/" + li.Value; // setting text value of item as tooltip
        }
    }
}

/// <summary>
/// Bind Dropdownlist Data
/// </summary>
protected void BindDropDownList()
{
    SqlConnection con = new SqlConnection("Data Source=SureshDasari;Initial Catalog=MySampleDB;Integrated Security=true");
    con.Open();
    SqlCommand cmd = new SqlCommand("select * from CountryImages", con);
    SqlDataAdapter da = new SqlDataAdapter(cmd);
    DataSet ds = new DataSet();
    da.Fill(ds);
    ddlCountry.DataTextField = "CountryName";
    ddlCountry.DataValueField = "CountryImage";
    ddlCountry.DataSource = ds;
    ddlCountry.DataBind();
    con.Close();
}
protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
{
    lbltext.Text = ddlCountry.SelectedItem.Text;
    BindTitles();
}
}
