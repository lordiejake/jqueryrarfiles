﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page 
{
protected void Page_Load(object sender, EventArgs e)
{
    if (!IsPostBack)
    {
        ViewState["Filter"] = "ALL";
        BindGrid();
    }
}

private void  BindGrid()
{
    DataTable dt = new DataTable();
    String strConnString = System.Configuration.ConfigurationManager
                .ConnectionStrings["conString"].ConnectionString;
    SqlConnection con = new SqlConnection(strConnString);
    SqlDataAdapter sda = new SqlDataAdapter();
    SqlCommand cmd = new SqlCommand("spx_GetCustomers");
    cmd.CommandType = CommandType.StoredProcedure;
    cmd.Parameters.AddWithValue("@Filter", ViewState["Filter"].ToString());
    cmd.Connection = con;
    sda.SelectCommand = cmd;
    sda.Fill(dt);
    GridView1.DataSource = dt;
    GridView1.DataBind();
    DropDownList ddlCountry = 
        (DropDownList)GridView1.HeaderRow.FindControl("ddlCountry");
    this.BindCountryList(ddlCountry);
}

protected void CountryChanged(object sender, EventArgs e)
{
    DropDownList ddlCountry = (DropDownList)sender;
    ViewState["Filter"] = ddlCountry.SelectedValue;
    this.BindGrid();
}

private void BindCountryList(DropDownList ddlCountry)
{
    String strConnString = System.Configuration.ConfigurationManager
                .ConnectionStrings["conString"].ConnectionString;
    SqlConnection con = new SqlConnection(strConnString);
    SqlDataAdapter sda = new SqlDataAdapter();
    SqlCommand cmd = new SqlCommand("select distinct Country" + 
                    " from customers");
    cmd.Connection = con;
    con.Open();
    ddlCountry.DataSource = cmd.ExecuteReader();
    ddlCountry.DataTextField = "Country";
    ddlCountry.DataValueField = "Country";
    ddlCountry.DataBind();
    con.Close();
    ddlCountry.Items.FindByValue(ViewState["Filter"].ToString())
            .Selected = true;
}

protected void OnPaging(object sender, GridViewPageEventArgs e)
{
    GridView1.PageIndex = e.NewPageIndex;
    this.BindGrid();
}
}
