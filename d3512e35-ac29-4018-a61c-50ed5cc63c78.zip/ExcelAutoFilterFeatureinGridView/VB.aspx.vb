﻿Imports System.Data.SqlClient
Imports System.Data

Partial Class VB
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            ViewState("Filter") = "ALL"
            BindGrid()
        End If
    End Sub

    Private Sub BindGrid()
        Dim dt As New DataTable()
        Dim strConnString As String = System.Configuration.ConfigurationManager _
            .ConnectionStrings("conString").ConnectionString
        Dim con As New SqlConnection(strConnString)
        Dim sda As New SqlDataAdapter()
        Dim cmd As New SqlCommand("spx_GetCustomers")
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.AddWithValue("@Filter", ViewState("Filter"))
        cmd.Connection = con
        sda.SelectCommand = cmd
        sda.Fill(dt)
        GridView1.DataSource = dt
        GridView1.DataBind()
        Dim ddlCountry As DropDownList = DirectCast(GridView1.HeaderRow _
            .FindControl("ddlCountry"), DropDownList)
        Me.BindCountryList(ddlCountry)
    End Sub

    Protected Sub CountryChanged(ByVal sender As Object, ByVal e As EventArgs)
        Dim ddlCountry As DropDownList = DirectCast(sender, DropDownList)
        ViewState("Filter") = ddlCountry.SelectedValue
        Me.BindGrid()
    End Sub

    Private Sub BindCountryList(ByVal ddlCountry As DropDownList)
        Dim strConnString As String = System.Configuration.ConfigurationManager _
            .ConnectionStrings("conString").ConnectionString
        Dim con As New SqlConnection(strConnString)
        Dim sda As New SqlDataAdapter()
        Dim cmd As New SqlCommand("select distinct Country" & _
                                    " from customers")
        cmd.Connection = con
        con.Open()
        ddlCountry.DataSource = cmd.ExecuteReader()
        ddlCountry.DataTextField = "Country"
        ddlCountry.DataValueField = "Country"
        ddlCountry.DataBind()
        con.Close()
        ddlCountry.Items.FindByValue(ViewState("Filter").ToString()) _
            .Selected = True
    End Sub

    Protected Sub OnPaging(sender As Object , e As GridViewPageEventArgs)
        GridView1.PageIndex = e.NewPageIndex
        Me.BindGrid()
    End Sub
End Class
