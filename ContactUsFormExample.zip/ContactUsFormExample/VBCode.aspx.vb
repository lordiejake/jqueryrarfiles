﻿Imports System.Net.Mail

Partial Class VBCode
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs)

    End Sub
    Protected Sub btnSubmit_Click(ByVal sender As Object, ByVal e As EventArgs)
        Try
            Dim Msg As New MailMessage()
            ' Sender e-mail address.
            Msg.From = New MailAddress(txtEmail.Text)
            ' Recipient e-mail address.
            Msg.[To].Add("administrator@aspdotnet-suresh.com")
            Msg.Subject = txtSubject.Text
            Msg.Body = txtMessage.Text
            ' your remote SMTP server IP.
            Dim smtp As New SmtpClient()
            smtp.Host = "smtp.gmail.com"
            smtp.Port = 587
            smtp.Credentials = New System.Net.NetworkCredential("yourusername@gmail.com", "yourpassword")
            smtp.EnableSsl = True
            smtp.Send(Msg)
            'Msg = null;
            lbltxt.Text = "Thanks for Contact us"
            ' Clear the textbox valuess
            txtName.Text = ""
            txtSubject.Text = ""
            txtMessage.Text = ""
            txtEmail.Text = ""
        Catch ex As Exception
            Console.WriteLine("{0} Exception caught.", ex)
        End Try
    End Sub
End Class
