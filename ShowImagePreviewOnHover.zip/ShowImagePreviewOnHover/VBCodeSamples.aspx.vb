﻿Imports System.Collections
Imports System.IO
Partial Class VBCodeSamples
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load

        If Not IsPostBack Then
            BindDataList()
        End If
    End Sub
    Protected Sub BindDataList()
        Dim dir As New DirectoryInfo(MapPath("Images"))
        Dim files As FileInfo() = dir.GetFiles()
        Dim listItems As New ArrayList()
        For Each info As FileInfo In files
            listItems.Add(info)
        Next
        dtlist.DataSource = listItems
        dtlist.DataBind()
    End Sub
End Class
