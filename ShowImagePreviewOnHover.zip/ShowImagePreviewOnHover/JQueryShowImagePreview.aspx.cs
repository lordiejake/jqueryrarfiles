﻿using System;
using System.Collections;
using System.IO;

public partial class JQueryShowImagePreview : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindDataList();
        }
    }
    protected void BindDataList()
    {
        DirectoryInfo dir = new DirectoryInfo(MapPath("Images"));
        FileInfo[] files = dir.GetFiles();
        ArrayList listItems = new ArrayList();
        foreach (FileInfo info in files)
        {
            listItems.Add(info);
        }
        dtlist.DataSource = listItems;
        dtlist.DataBind();
    }
 }
